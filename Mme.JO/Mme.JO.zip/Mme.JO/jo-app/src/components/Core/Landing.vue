<template>
<v-main>
<section class="welcome">


 <v-img
fluid
 lazy-src="require('@/assets/backjo.png')" 
 :src="require('@/assets/backjo.png')"
 ></v-img>
  

</section>
</v-main>

</template>

<!-- <style lang="scss" scoped>

.welcome{
 background-size: cover;
width: 100%;
    height: 100%;
   
    top: 0;
    left: 0;

}
</style> -->


