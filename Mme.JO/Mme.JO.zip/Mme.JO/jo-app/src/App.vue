<template>
  <v-app>
   
    <v-main>
     <Navbar />
      <Landing />
      <Footerbar />
    </v-main>
  </v-app>
</template>

<script>
import Landing from './components/Core/Landing.vue'
import Navbar from './components/Core/Navbar.vue'
import Footerbar from './components/Core/Footerbar.vue'
export default {
  name: 'App',

  components: {
   Navbar,
    Landing,
    Footerbar
  },

  data: () => ({
    //
  }),
};
</script>
